<?php
// api/index.php  — RESTful CRUD API
// Routes:
//   GET    /api/?resource=categories
//   GET    /api/?resource=categories&id=1
//   POST   /api/?resource=categories          body: {name, sort_order}
//   PUT    /api/?resource=categories&id=1     body: {name, sort_order}
//   DELETE /api/?resource=categories&id=1
//   (same pattern for resource=slides)
//   GET    /api/?resource=slides&category_id=1  — slides for one category

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/../config.php';

$method   = $_SERVER['REQUEST_METHOD'];
$resource = $_GET['resource'] ?? '';
$id       = isset($_GET['id']) ? (int)$_GET['id'] : null;
$input    = json_decode(file_get_contents('php://input'), true) ?? [];

function respond(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

function notFound(): void {
    respond(['error' => 'Resource not found'], 404);
}

$pdo = getDBConnection();

// ─── CATEGORIES ──────────────────────────────────────────────────────────────
if ($resource === 'categories') {
    switch ($method) {
        case 'GET':
            if ($id) {
                $stmt = $pdo->prepare('SELECT * FROM categories WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                $row ? respond($row) : notFound();
            } else {
                $stmt = $pdo->query('SELECT * FROM categories ORDER BY sort_order, id');
                respond($stmt->fetchAll());
            }
            break;

        case 'POST':
            $name  = trim($input['name'] ?? '');
            $order = (int)($input['sort_order'] ?? 0);
            if ($name === '') respond(['error' => 'name is required'], 422);
            $stmt = $pdo->prepare('INSERT INTO categories (name, sort_order) VALUES (?, ?)');
            $stmt->execute([$name, $order]);
            respond(['id' => (int)$pdo->lastInsertId(), 'name' => $name, 'sort_order' => $order], 201);
            break;

        case 'PUT':
            if (!$id) respond(['error' => 'id required'], 422);
            $name  = trim($input['name'] ?? '');
            $order = (int)($input['sort_order'] ?? 0);
            if ($name === '') respond(['error' => 'name is required'], 422);
            $stmt = $pdo->prepare('UPDATE categories SET name=?, sort_order=? WHERE id=?');
            $stmt->execute([$name, $order, $id]);
            $stmt->rowCount() ? respond(['id' => $id, 'name' => $name, 'sort_order' => $order]) : notFound();
            break;

        case 'DELETE':
            if (!$id) respond(['error' => 'id required'], 422);
            $stmt = $pdo->prepare('DELETE FROM categories WHERE id=?');
            $stmt->execute([$id]);
            $stmt->rowCount() ? respond(['deleted' => true]) : notFound();
            break;

        default:
            respond(['error' => 'Method not allowed'], 405);
    }
}

// ─── SLIDES ──────────────────────────────────────────────────────────────────
elseif ($resource === 'slides') {
    switch ($method) {
        case 'GET':
            if ($id) {
                $stmt = $pdo->prepare('SELECT * FROM slides WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                $row ? respond($row) : notFound();
            } elseif (isset($_GET['category_id'])) {
                $catId = (int)$_GET['category_id'];
                $stmt  = $pdo->prepare('SELECT * FROM slides WHERE category_id=? ORDER BY sort_order, id');
                $stmt->execute([$catId]);
                respond($stmt->fetchAll());
            } else {
                $stmt = $pdo->query('SELECT s.*, c.name AS category_name FROM slides s JOIN categories c ON s.category_id=c.id ORDER BY c.sort_order, s.sort_order');
                respond($stmt->fetchAll());
            }
            break;

        case 'POST':
            $catId = (int)($input['category_id'] ?? 0);
            $title = trim($input['title'] ?? '');
            $desc  = trim($input['description'] ?? '');
            $img   = trim($input['image_url'] ?? '');
            $order = (int)($input['sort_order'] ?? 0);
            if (!$catId || $title === '' || $img === '') respond(['error' => 'category_id, title and image_url are required'], 422);
            $stmt = $pdo->prepare('INSERT INTO slides (category_id, title, description, image_url, sort_order) VALUES (?,?,?,?,?)');
            $stmt->execute([$catId, $title, $desc, $img, $order]);
            respond(['id' => (int)$pdo->lastInsertId(), 'category_id' => $catId, 'title' => $title, 'description' => $desc, 'image_url' => $img, 'sort_order' => $order], 201);
            break;

        case 'PUT':
            if (!$id) respond(['error' => 'id required'], 422);
            $catId = (int)($input['category_id'] ?? 0);
            $title = trim($input['title'] ?? '');
            $desc  = trim($input['description'] ?? '');
            $img   = trim($input['image_url'] ?? '');
            $order = (int)($input['sort_order'] ?? 0);
            if (!$catId || $title === '' || $img === '') respond(['error' => 'category_id, title and image_url are required'], 422);
            $stmt = $pdo->prepare('UPDATE slides SET category_id=?,title=?,description=?,image_url=?,sort_order=? WHERE id=?');
            $stmt->execute([$catId, $title, $desc, $img, $order, $id]);
            $stmt->rowCount() ? respond(['id' => $id, 'category_id' => $catId, 'title' => $title, 'description' => $desc, 'image_url' => $img, 'sort_order' => $order]) : notFound();
            break;

        case 'DELETE':
            if (!$id) respond(['error' => 'id required'], 422);
            $stmt = $pdo->prepare('DELETE FROM slides WHERE id=?');
            $stmt->execute([$id]);
            $stmt->rowCount() ? respond(['deleted' => true]) : notFound();
            break;

        default:
            respond(['error' => 'Method not allowed'], 405);
    }
}

else {
    respond(['error' => 'Unknown resource. Use ?resource=categories or ?resource=slides'], 400);
}
