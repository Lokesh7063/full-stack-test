/* js/admin.js — WPoets Admin CRUD */

const API = 'api/index.php';

// ── Toast ─────────────────────────────────────────────────────────
function showToast(msg, type = 'success') {
  const icon  = type === 'success' ? '✓' : '✕';
  const $wrap = $('#toast-container');
  const $t    = $(`<div class="toast-msg ${type}"><span>${icon}</span><span>${msg}</span></div>`);
  $wrap.append($t);
  setTimeout(() => $t.fadeOut(300, () => $t.remove()), 3000);
}

// ── Image preview ─────────────────────────────────────────────────
$('#slideImg').on('input', function () {
  const url = $(this).val().trim();
  if (url) {
    $('#imgPreview').attr('src', url).removeClass('d-none');
  } else {
    $('#imgPreview').addClass('d-none').attr('src', '');
  }
});

// ── CATEGORY CRUD ─────────────────────────────────────────────────
function openCatModal(cat = null) {
  $('#catModalTitle').text(cat ? 'Edit Category' : 'Add Category');
  $('#catId').val(cat ? cat.id : '');
  $('#catName').val(cat ? cat.name : '');
  $('#catOrder').val(cat ? cat.sort_order : 0);
}

function saveCategory() {
  const id    = $('#catId').val();
  const name  = $('#catName').val().trim();
  const order = parseInt($('#catOrder').val(), 10) || 0;

  if (!name) { showToast('Name is required', 'error'); return; }

  const method = id ? 'PUT' : 'POST';
  const url    = id ? `${API}?resource=categories&id=${id}` : `${API}?resource=categories`;

  $.ajax({
    url, method,
    contentType: 'application/json',
    data: JSON.stringify({ name, sort_order: order }),
    success(res) {
      bootstrap.Modal.getInstance(document.getElementById('catModal')).hide();
      showToast(id ? 'Category updated' : 'Category created');
      setTimeout(() => location.reload(), 800);
    },
    error(xhr) {
      const err = JSON.parse(xhr.responseText || '{}').error || 'Request failed';
      showToast(err, 'error');
    },
  });
}

function deleteCategory(id, name) {
  if (!confirm(`Delete category "${name}" and all its slides? This cannot be undone.`)) return;
  $.ajax({
    url: `${API}?resource=categories&id=${id}`,
    method: 'DELETE',
    success() {
      showToast('Category deleted');
      $(`#catTable tbody tr[data-id="${id}"]`).fadeOut(400, function () { $(this).remove(); });
    },
    error(xhr) {
      const err = JSON.parse(xhr.responseText || '{}').error || 'Delete failed';
      showToast(err, 'error');
    },
  });
}

// ── SLIDE CRUD ────────────────────────────────────────────────────
function openSlideModal(slide = null) {
  $('#slideModalTitle').text(slide ? 'Edit Slide' : 'Add Slide');
  $('#slideId').val(slide ? slide.id : '');
  $('#slideCatId').val(slide ? slide.category_id : '');
  $('#slideTitle').val(slide ? slide.title : '');
  $('#slideDesc').val(slide ? slide.description : '');
  $('#slideImg').val(slide ? slide.image_url : '');
  $('#slideOrder').val(slide ? slide.sort_order : 0);

  if (slide && slide.image_url) {
    $('#imgPreview').attr('src', slide.image_url).removeClass('d-none');
  } else {
    $('#imgPreview').addClass('d-none').attr('src', '');
  }
}

function saveSlide() {
  const id    = $('#slideId').val();
  const catId = parseInt($('#slideCatId').val(), 10);
  const title = $('#slideTitle').val().trim();
  const desc  = $('#slideDesc').val().trim();
  const img   = $('#slideImg').val().trim();
  const order = parseInt($('#slideOrder').val(), 10) || 0;

  if (!catId || !title || !img) {
    showToast('Category, title and image URL are required', 'error');
    return;
  }

  const method = id ? 'PUT' : 'POST';
  const url    = id ? `${API}?resource=slides&id=${id}` : `${API}?resource=slides`;

  $.ajax({
    url, method,
    contentType: 'application/json',
    data: JSON.stringify({ category_id: catId, title, description: desc, image_url: img, sort_order: order }),
    success() {
      bootstrap.Modal.getInstance(document.getElementById('slideModal')).hide();
      showToast(id ? 'Slide updated' : 'Slide created');
      setTimeout(() => location.reload(), 800);
    },
    error(xhr) {
      const err = JSON.parse(xhr.responseText || '{}').error || 'Request failed';
      showToast(err, 'error');
    },
  });
}

function deleteSlide(id, title) {
  if (!confirm(`Delete slide "${title}"?`)) return;
  $.ajax({
    url: `${API}?resource=slides&id=${id}`,
    method: 'DELETE',
    success() {
      showToast('Slide deleted');
      $(`#slideTable tbody tr[data-id="${id}"]`).fadeOut(400, function () { $(this).remove(); });
    },
    error(xhr) {
      const err = JSON.parse(xhr.responseText || '{}').error || 'Delete failed';
      showToast(err, 'error');
    },
  });
}
