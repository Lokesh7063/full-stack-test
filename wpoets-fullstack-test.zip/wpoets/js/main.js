/* js/main.js — WPoets Portfolio
   Handles:
   - Desktop: tab switching → show correct Swiper + sync feature image
   - Desktop: Swiper slide change → update feature image (col 3)
   - Mobile: accordion open → init/activate mobile Swipers
*/
$(function () {

  // ── Desktop Swiper registry ───────────────────────────────────────
  const desktopSwipers = {};

  // Initialise one desktop Swiper per category
  WP_DATA.categories.forEach(cat => {
    const slides = WP_DATA.slidesByCategory[cat.id] || [];
    if (!slides.length) return;

    const swiper = new Swiper(`#desktopSwiper${cat.id}`, {
      loop: false,
      speed: 500,
      navigation: {
        prevEl: `#prev${cat.id}`,
        nextEl: `#next${cat.id}`,
      },
      pagination: {
        el: `#pag${cat.id}`,
        clickable: true,
      },
      on: {
        slideChange(sw) {
          updateFeatureImage(cat.id, sw.realIndex);
        },
      },
    });

    desktopSwipers[cat.id] = swiper;
  });

  // ── Feature image helper ─────────────────────────────────────────
  function updateFeatureImage(catId, slideIndex) {
    const slides = WP_DATA.slidesByCategory[catId] || [];
    const slide  = slides[slideIndex];
    if (!slide) return;

    const $img     = $('#featureImg');
    const total    = slides.length;
    const counter  = String(slideIndex + 1).padStart(2, '0') + ' / ' + String(total).padStart(2, '0');

    $img.addClass('fading');
    setTimeout(() => {
      $img.attr('src', slide.image_url).attr('alt', slide.title);
      $('#featureCounter').text(counter);
      $img.removeClass('fading');
    }, 250);
  }

  // ── Tab click ────────────────────────────────────────────────────
  $('#categoryTabs').on('click', '.tab-btn', function () {
    const catId = $(this).data('category');

    // Update tab active state
    $('.tab-btn').removeClass('active');
    $(this).addClass('active');

    // Show correct slider panel
    $('.desktop-slider-wrap').removeClass('active');
    $(`.desktop-slider-wrap[data-category="${catId}"]`).addClass('active');

    // Update feature image to current slide of newly active swiper
    const sw = desktopSwipers[catId];
    if (sw) {
      updateFeatureImage(catId, sw.realIndex);
      sw.update(); // recalc layout after display:none → display:block
    }
  });

  // ── Mobile Swipers ────────────────────────────────────────────────
  const mobileSwipers = {};

  function initMobileSwiper(catId) {
    if (mobileSwipers[catId]) return; // already initialised
    mobileSwipers[catId] = new Swiper(`#mobileSwiper${catId}`, {
      loop: false,
      speed: 400,
      pagination: {
        el: `#mobileSwiper${catId} .swiper-pagination`,
        clickable: true,
      },
    });
  }

  // Init first accordion's swiper immediately
  const firstCatId = WP_DATA.categories[0]?.id;
  if (firstCatId) initMobileSwiper(firstCatId);

  // Init swiper when accordion opens
  $('#mobileAccordion').on('show.bs.collapse', function (e) {
    const catId = parseInt($(e.target).attr('id').replace('acc', ''), 10);
    // Small delay so display:block has happened
    setTimeout(() => initMobileSwiper(catId), 50);
  });

});
